'use strict';
const { getTraceContext } = require('./otel');
const EventEmitter = require('node:events');

const LEVELS = { debug: 0, info: 1, warn: 2, error: 3 };
const CURRENT = LEVELS[process.env.LOG_LEVEL] ?? LEVELS.info;
const SERVICE = process.env.SERVICE_NAME || 'app';
const ENV = process.env.NODE_ENV || 'production';

// Ring buffer en memoria para el dashboard web
const RING_SIZE = 500;
const ring = [];
const bus = new EventEmitter();
bus.setMaxListeners(100);

function safeStringify(obj) {
  const seen = new WeakSet();
  return JSON.stringify(obj, (k, v) => {
    if (typeof v === 'object' && v !== null) {
      if (seen.has(v)) return '[Circular]';
      seen.add(v);
    }
    if (v instanceof Error) return { name: v.name, message: v.message, stack: v.stack };
    return v;
  });
}

function emit(level, msg, meta) {
  const trace = getTraceContext();
  const entry = {
    ts: new Date().toISOString(),
    level, msg, svc: SERVICE, env: ENV,
    ...(trace && trace),
    ...(meta && { meta }),
  };
  const line = safeStringify(entry);
  process.stdout.write(line + '\n');
  ring.push(entry);
  if (ring.length > RING_SIZE) ring.shift();
  bus.emit('log', entry);
}

function make(level) {
  if (LEVELS[level] < CURRENT) return () => {};
  return (msg, meta) => emit(level, msg, meta);
}

module.exports = {
  debug: make('debug'),
  info:  make('info'),
  warn:  make('warn'),
  error: make('error'),
  child: (b) => ({
    debug: (m, x) => emit('debug', m, { ...b, ...x }),
    info:  (m, x) => emit('info',  m, { ...b, ...x }),
    warn:  (m, x) => emit('warn',  m, { ...b, ...x }),
    error: (m, x) => emit('error', m, { ...b, ...x }),
  }),
  _ring: () => ring.slice(),
  _bus: bus,
};
