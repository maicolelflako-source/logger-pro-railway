'use strict';
let otelApi = null;
try { otelApi = require('@opentelemetry/api'); } catch {}
function getTraceContext() {
  if (!otelApi) return null;
  const span = otelApi.trace.getActiveSpan();
  if (!span) return null;
  const c = span.spanContext();
  if (!c?.traceId) return null;
  return { trace_id: c.traceId, span_id: c.spanId };
}
module.exports = { getTraceContext };
